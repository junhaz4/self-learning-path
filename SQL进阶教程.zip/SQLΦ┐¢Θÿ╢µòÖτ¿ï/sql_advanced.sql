create table Greatests (
keyy char(1) primary key,
xx integer not null,
yy integer not null,
zz integer not null
);
INSERT INTO Greatests VALUES('A', 1, 2, 3);
INSERT INTO Greatests VALUES('B', 5, 5, 2);
INSERT INTO Greatests VALUES('C', 4, 7, 1);
INSERT INTO Greatests VALUES('D', 3, 3, 8);
select * from Greatests;

select keyy, 
case when xx<yy then yy
else xx end as greatest
from Greatests;