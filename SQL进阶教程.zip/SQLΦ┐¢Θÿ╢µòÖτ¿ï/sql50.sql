-- 学生表 Student
-- Sn 学生编号,Sname 学生姓名,Sage 出生年月,Ssex 学生性别
create table Student(
Sn varchar(10), 
Sname nvarchar(10),
Sage datetime,
Ssex nvarchar(10)
);
insert into Student values('01' , N'赵雷' , '1990-01-01' , N'男');
insert into Student values('02' , N'钱电' , '1990-12-21' , N'男');
insert into Student values('03' , N'孙风' , '1990-05-20' , N'男');
insert into Student values('04' , N'李云' , '1990-08-06' , N'男');
insert into Student values('05' , N'周梅' , '1991-12-01' , N'女');
insert into Student values('06' , N'吴兰' , '1992-03-01' , N'女');
insert into Student values('07' , N'郑竹' , '1989-07-01' , N'女');
insert into Student values('08' , N'王菊' , '1990-01-20' , N'女');

-- 科目表 Course
-- Cn --课程编号,Cname 课程名称,Tn 教师编号
create table Course(
Cn varchar(10),
Cname nvarchar(10),
Tn varchar(10)
);
insert into Course values('01' , N'语文' , '02');
insert into Course values('02' , N'数学' , '01');
insert into Course values('03' , N'英语' , '03');


-- 教师表 Teacher
-- Tn 教师编号,Tname 教师姓名
create table Teacher(
Tn varchar(10),
Tname nvarchar(10)
);
insert into Teacher values('01' , N'张三');
insert into Teacher values('02' , N'李四');
insert into Teacher values('03' , N'王五');


-- 成绩表 SC
-- Sn 学生编号,Cn 课程编号,score 分数
create table SC(
Sn varchar(10),
Cn varchar(10),
score decimal(18,1)
);
insert into SC values('01' , '01' , 80);
insert into SC values('01' , '02' , 90);
insert into SC values('01' , '03' , 99);
insert into SC values('02' , '01' , 70);
insert into SC values('02' , '02' , 60);
insert into SC values('02' , '03' , 80);
insert into SC values('03' , '01' , 80);
insert into SC values('03' , '02' , 80);
insert into SC values('03' , '03' , 80);
insert into SC values('04' , '01' , 50);
insert into SC values('04' , '02' , 30);
insert into SC values('04' , '03' , 20);
insert into SC values('05' , '01' , 76);
insert into SC values('05' , '02' , 87);
insert into SC values('06' , '01' , 31);
insert into SC values('06' , '03' , 34);
insert into SC values('07' , '02' , 89);
insert into SC values('07' , '03' , 98);

-- 1. 查询" 01 "课程比" 02 "课程成绩高的学生的信息及课程分数
select A.*,B.Cn,B.score,C.Cn,C.score
from Student A, (select * from SC where Cn='01') B,(select * from SC where Cn='02') C
where A.Sn=B.Sn and A.Sn=C.Sn and B.score>C.score;

-- 1.1 查询同时存在" 01 "课程和" 02 "课程的情况
select * 
from (select * from SC where Cn='01') A, (select * from SC where Cn='02') B
where A.Sn=B.Sn;

-- 1.2 查询存在" 01 "课程但可能不存在" 02 "课程的情况(不存在时显示为 null )
select * 
from (select * from SC where Cn='01') A left join (select * from SC where Cn='02') B
on A.Sn=B.Sn;

-- 1.3 查询不存在" 01 "课程但存在" 02 "课程的情况
#方法一
select * from SC where Cn='02' and Sn not in (select Sn from SC where Cn='01');
#方法二
select * 
from (select * from SC where Cn='01') A right join (select * from SC where Cn='02') B
on A.Sn=B.Sn;

-- 2. 查询平均成绩大于等于 60 分的同学的学生编号和学生姓名和平均成绩
#方法一
select A.Sn,A.Sname,t.avg
from Student A, (select Sn, avg(score) avg from SC group by Sn having avg>60) t
where A.Sn=t.Sn;
#方法二
select A.Sn,B.Sname,A.dc from(select Sn,AVG(score)dc from SC group by Sn)A
left join Student B on A.Sn=B.Sn where A.dc>=60;

-- 3. 查询在 SC 表存在成绩的学生信息
#方法一
select distinct B.*
from SC A, Student B
where A.Sn=B.Sn;
#方法二
select * from Student where Sn in (select distinct Sn from SC);

-- 4. 查询所有同学的学生编号、学生姓名、选课总数、所有课程的总成绩(没成绩的显示为 null )
select A.Sn,A.Sname,t.count,t.sum
from Student A left join (select Sn, count(Cn) count, sum(score) sum from SC group by Sn) t
on A.Sn=t.Sn;

-- 4.1 查有成绩的学生信息
#方法一
select A.Sn,A.Sname,t.count,t.sum
from Student A right join (select Sn, count(Cn) count, sum(score) sum from SC group by Sn) t
on A.Sn=t.Sn;
#方法二
select A.Sn,A.Sname,t.count,t.sum
from Student A right join (select Sn, count(Cn) count, sum(score) sum from SC group by Sn) t
on A.Sn=t.Sn where t.count is not null;

-- 5. 查询「李」姓老师的数量 
select count(Tname) from Teacher where Tname like '李%';

-- 6. 查询学过「张三」老师授课的同学的信息 
#方法一
select A.* from Student A, SC B
where A.Sn=B.Sn and B.Cn=(select Cn from Course where Tn=(select Tn from Teacher where Tname='张三'));
#方法二
select * from Student
where Sn in(select distinct Sn from SC 
where Cn=(select Cn from Course 
where Tn=(select Tn from Teacher where Tname='张三')));

-- 7. 查询没有学全所有课程的同学的信息 
#方法一
select A.*
from Student A, (select Sn, count(Cn) count from SC group by Sn having count<3) B
where A.Sn=B.Sn;
#方法二
select * from Student 
where Sn in(select Sn from SC group by Sn having COUNT(Cn)<3);

-- 8. 查询至少有一门课与学号为" 01 "的同学所学相同的同学的信息 
select * from Student 
where Sn in (select distinct Sn from SC where Cn  in (select Cn from SC where Sn='01'));

-- 9. 查询和" 01 "号的同学学习的课程完全相同的其他同学的信息 
select * from Student where Sn in 
(select Sn from SC where Cn in (select distinct Cn from SC where Sn ='01') and Sn!='01'
group by Sn having count(Cn) >2);

-- 10. 查询没学过"张三"老师讲授的任一门课程的学生姓名 
select Sn from SC where Cn =(select Cn from Course where Tn=(select Tn from Teacher where Tname='张三'));
select Sname from Student 
where Sn not in (select Sn from SC 
where Cn =(select Cn from Course where Tn=(select Tn from Teacher where Tname='张三')));

-- 11. 查询两门及其以上不及格课程的同学的学号，姓名及其平均成绩
select A.Sn, A.Sname,B.pj
from Student A, (select Sn,sum(score<60) total ,avg(score) pj from SC group by Sn having total >=2) B
where A.Sn=B.Sn;

-- 12. 检索" 01 "课程分数小于 60，按分数降序排列的学生信息
select A.*,t.score
from Student A, (select Sn, score from SC where Cn='01'and score <60) t
where A.Sn=t.Sn order by t.score desc;

-- 13. 按平均成绩从高到低显示所有学生的所有课程的成绩以及平均成绩
select Sn, 
sum(case when Cn='01' then score else null end) score01,
sum(case when Cn='02' then score else null end) score02,
sum(case when Cn='03' then score else null end) score03,
avg(score) from SC group by Sn order by avg(score) desc;

-- 14. 查询各科成绩最高分、最低分和平均分：
/* 以如下形式显示：课程 ID，课程 name，最高分，最低分，平均分，及格率，中等率，优良率，优秀率
   及格为>=60，中等为：70-80，优良为：80-90，优秀为：>=90
   要求输出课程号和选修人数，查询结果按人数降序排列，若人数相同，按课程号升序排列 */
select c.Cn 课程号, count(sc.Cn) 人数, 
max(sc.score) 最高分, min(sc.score) 最低分, avg(sc.score) 平均分,
sum(case when sc.score>=60 then 1 else 0 end)/count(sc.Cn) 及格率,
sum(case when sc.score>=70 and sc.score<80 then 1 else 0 end)/count(sc.Cn) 中等率,
sum(case when sc.score>=80 and sc.score<90 then 1 else 0 end)/count(sc.Cn) 优良率,
sum(case when sc.score>=90 then 1 else 0 end)/count(sc.Cn) 优秀率
from Course c, SC sc
where c.Cn=sc.Cn
group by c.Cn
order by count(sc.Cn) desc, c.Cn asc;

-- 15. 按各科成绩进行排序，并显示排名， Score 重复时保留名次空缺
select *, rank() over (order by score desc) from SC;

-- 15.1 按各科成绩进行排序，并显示排名， Score 重复时合并名次
select *, dense_rank() over (order by score desc) from SC;

-- 16.  查询学生的总成绩，并进行排名，总分重复时保留名次空缺
select Sn, sum(score) from SC group by Sn order by sum(score) desc;
select *, rank() over(order by t.total desc) from (select Sn, sum(score) total from SC group by Sn) t;

-- 16.1 查询学生的总成绩，并进行排名，总分重复时不保留名次空缺
select *, dense_rank() over(order by t.total desc) from (select Sn, sum(score) total from SC group by Sn) t;

-- 17. 统计各科成绩各分数段人数：课程编号，课程名称，[100-85]，[85-70]，[70-60]，[60-0] 及所占百分比
select c.Cn,
sum(case when sc.score>=85 then 1 else 0 end)/count(sc.Cn) '[100-85]',
sum(case when sc.score>=70 and sc.score<85 then 1 else 0 end)/count(sc.Cn) '[85-70]',
sum(case when sc.score>=60 and sc.score<70 then 1 else 0 end)/count(sc.Cn)'[70-60]',
sum(case when sc.score<60 then 1 else 0 end)/count(sc.Cn)'[60-0]'
from Course c, SC sc where c.Cn=sc.Cn group by c.Cn;

select c.Cn,c.Cname,t.*
from Course c,
(select Cn,
sum(case when sc.score>=85 then 1 else 0 end)/count(sc.Cn) '[100-85]',
sum(case when sc.score>=70 and sc.score<85 then 1 else 0 end)/count(sc.Cn) '[85-70]',
sum(case when sc.score>=60 and sc.score<70 then 1 else 0 end)/count(sc.Cn)'[70-60]',
sum(case when sc.score<60 then 1 else 0 end)/count(sc.Cn)'[60-0]'
from SC sc group by Cn) t 
where c.Cn=t.Cn;

-- 18. 查询各科成绩前三名的记录
select *, rank() over(partition by Cn order by score desc) from SC;
select * from 
(select *, rank() over(partition by Cn order by score desc) grade from SC) t
where t.grade<=3;

-- 19. 查询每门课程被选修的学生数 
select Sn, count(Cn) from SC group by Sn;

-- 20. 查询出只选修两门课程的学生学号和姓名 
#方法一
select s.Sn,count(sc.Cn),s.Sname
from Student s, SC sc
where s.Sn=sc.Sn
group by s.Sn, s.Sname
having count(sc.Cn)=2;
#方法二
select Sn, Sname from Student 
where Sn in (select Sn from SC group by Sn having count(Cn)=2);

-- 21. 查询男生、女生人数
select Ssex, count(Ssex) from Student group by Ssex;

-- 22. 查询名字中含有「风」字的学生信息
select * from Student where Sname like '%风%';

-- 23. 查询同名同性学生名单，并统计同名人数
select Sname, Ssex, count(Sname) total from Student group by Sname, Ssex;
select A.*,B.total 
from Student A left join (select Sname, Ssex, count(Sname) total from Student group by Sname, Ssex) B
on A.Sname=B.Sname and A.Ssex=B.Ssex
where B.total>1;

-- 24. 查询 1990 年出生的学生名单
select * from Student where year(Sage)=1990;

-- 25. 查询每门课程的平均成绩，结果按平均成绩降序排列，平均成绩相同时，按课程编号升序排列
select Cn,avg(score) from SC group by Cn order by avg(score) desc,Cn asc;

-- 26. 查询平均成绩大于等于 85 的所有学生的学号、姓名和平均成绩 
#方法一
select Sn, avg(score) average from SC group by Sn having avg(score)>85;
select A.Sn,A.Sname,B.average
from Student A, (select Sn, avg(score) average from SC group by Sn having avg(score)>85) B
where A.Sn=B.Sn;
#方法二
select A.Sn,A.Sname,B.average
from Student A left join (select Sn, avg(score) average from SC group by Sn) B
on A.Sn=B.Sn where B.average>85;

-- 27. 查询课程名称为「数学」，且分数低于 60 的学生姓名和分数 
#方法一
select A.Sname,B.score
from Student A, (select Sn,score from SC where Cn=(select Cn from Course where Cname='数学') and score <60) B
where A.Sn=B.Sn;
#方法二
select A.Sname,B.score
from Student A left join (select Sn,score from SC where Cn=(select Cn from Course where Cname='数学')) B
on A.Sn=B.Sn where B.score<60;

-- 28. 查询所有学生的课程及分数情况（存在学生没成绩，没选课的情况）
select A.Sn,A.Sname,B.Cn,B.score
from Student A left join SC B 
on A.Sn=B.Sn;

-- 29. 查询任何一门课程成绩在 70 分以上的姓名、课程名称和分数
select Sn,Cn,score from SC where score>70;
select A.Sname,B.Cn,B.score
from Student A, (select * from SC where score>70) B
where A.Sn=B.Sn;

-- 30. 查询不及格的课程
select Sn,Cn from SC where score <60;

-- 31. 查询课程编号为 01 且课程成绩在 80 分以上的学生的学号和姓名
select A.Sn, A.Sname
from Student A, (select Sn,score from SC where Cn=01 and score>80) B
where A.Sn=B.Sn;

-- 32. 求每门课程的学生人数 
select Cn, count(Sn)from SC group by Cn;

-- 33. 成绩不重复，查询选修「张三」老师所授课程的学生中，成绩最高的学生信息及其成绩
select A.*,B.score
from Student A, (select * from SC 
where Cn=(select Cn from Course where Tn =(select Tn from Teacher where Tname='张三'))
order by score desc limit 0,1) B
where A.Sn=B.Sn;

-- 34. 成绩有重复的情况下，查询选修「张三」老师所授课程的学生中，成绩最高的学生信息及其成绩
select *,dense_rank() over(order by score desc) A from SC
where Cn=(select Cn from Course where Tn =(select Tn from Teacher where Tname='张三'));
select * from 
(select *,dense_rank() over(order by score desc) A 
from SC
where Cn=(select Cn from Course where Tn =(select Tn from Teacher where Tname='张三'))) B 
where B.A=1;

-- 35. 查询不同课程成绩相同的学生的学生编号、课程编号、学生成绩 
select distinct A.Sn,A.Cn,A.score
from SC A, SC B
where A.Sn=B.Sn and A.Cn!=B.Cn and A.score=B.score;

select C.Sn,max(C.Cn)Cn,max(C.score)score from SC C 
left join(select Sn,avg(score)A from SC group by Sn)B 
on C.Sn=B.Sn
where C.score=B.A
group by C.Sn
having COUNT(0)=(select COUNT(0)from SC where Sn=C.Sn);

-- 36. 查询每门功成绩最好的前两名
select * from 
(select *, row_number() over(partition by Cn order by score desc) A from SC) B
where B.A<3;

-- 37. 统计每门课程的学生选修人数（超过 5 人的课程才统计）。
select Cn, count(Sn) from SC group by Cn having count(Sn)>5;

-- 38. 检索至少选修两门课程的学生学号 
select Sn, count(Cn) from SC group by Sn having count(Cn)>=2;

-- 39. 查询选修了全部课程的学生信息
select Sn from SC group by Sn having count(Cn)=(select distinct count(*) from Course);

-- 40. 查询各学生的年龄，只按年份来算 
select Sname,year(now())-year(Sage) as age from Student;

-- 41. 按照出生日期来算，当前月日 < 出生年月的月日则，年龄减一
select Sname,timestampdiff(year,Sage,now()) as age from Student;

-- 42. 查询本周过生日的学生
select * from Student where week(Sage)=week(now());

-- 43. 查询下周过生日的学生
select * from Student where week(Sage)=week(now())+1;

-- 44. 查询本月过生日的学生
select * from Student where month(Sage)=month(now());

-- 45. 查询下月过生日的学生
select * from Student where month(Sage)=month(now())+1;


CREATE TABLE dept_emp (
emp_no int(11) NOT NULL,
dept_no char(4) NOT NULL,
from_date date NOT NULL,
to_date date NOT NULL,
PRIMARY KEY (emp_no,dept_no));

CREATE TABLE salaries(
emp_no int(11) NOT NULL,
salary int(11) NOT NULL,
from_date date NOT NULL,
to_date date NOT NULL,
PRIMARY KEY (emp_no,from_date));




